#pragma once 

#include <stdint.h>
#include "stdbool.h"

#define MODEM_PWRS_TIMEOUT 1500

typedef enum {
  PWR_MODEM,
} pwr_component_t;

bool pwr_enable(pwr_component_t component);
bool pwr_disable(pwr_component_t component);
bool pwr_is_enabled(pwr_component_t component);
