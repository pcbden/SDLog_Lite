#pragma once

#include <stdint.h>
#include "stm32l1xx_hal.h"

//pwrs pin of the modem. (On or Off pin)
//(MODEM ON)Set High until MODEM_STATUS_Pin goes high, then set low
//(MODEM OFF)Set High until MODEM_STATUS_Pin goes low, then set low
#define MODEM_PWRS_Pin GPIO_PIN_10
#define MODEM_PWRS_Port GPIOC

#define MODEM_STATUS_Pin GPIO_PIN_1
#define MODEM_STATUS_Port GPIOB

#define BUTTON_AND_BOOT_Pin GPIO_PIN_13
#define BUTTON_AND_BOOT_Port GPIOC
