#include "pwr_manager.h"
#include "gpio_drivers.h"
bool pwr_enable(pwr_component_t component){
  if(component == PWR_MODEM){
    if(gpio_get(MODEM_STATUS_Port,MODEM_STATUS_Pin) == GPIO_STATE_HIGH){
      return true;
    }
    uint32_t start = HAL_GetTick();
    gpio_set(MODEM_PWRS_Port,MODEM_PWRS_Pin,GPIO_STATE_HIGH);
    while(gpio_get(MODEM_STATUS_Port,MODEM_STATUS_Pin) != GPIO_STATE_HIGH){
      if((HAL_GetTick() - start) > MODEM_PWRS_TIMEOUT){
        gpio_set(MODEM_PWRS_Port,MODEM_PWRS_Pin,GPIO_STATE_LOW);
        return false;
      }
    }
    gpio_set(MODEM_PWRS_Port,MODEM_PWRS_Pin,GPIO_STATE_LOW);
    return true;
   }
  return false;
}
bool pwr_disable(pwr_component_t component){
  if(component == PWR_MODEM){
    if(gpio_get(MODEM_STATUS_Port,MODEM_STATUS_Pin) == GPIO_STATE_LOW){
      return true;
    }
    uint32_t start = HAL_GetTick();
    gpio_set(MODEM_PWRS_Port,MODEM_PWRS_Pin,GPIO_STATE_HIGH);
    while(gpio_get(MODEM_STATUS_Port,MODEM_STATUS_Pin) != GPIO_STATE_LOW){
      if((HAL_GetTick() - start) > MODEM_PWRS_TIMEOUT){
        gpio_set(MODEM_PWRS_Port,MODEM_PWRS_Pin,GPIO_STATE_LOW);
        return false;
      }
    }
    gpio_set(MODEM_PWRS_Port,MODEM_PWRS_Pin,GPIO_STATE_LOW);
    return true;
  }
  return false;
}
bool pwr_is_enabled(pwr_component_t component){
  if(component == PWR_MODEM){
    if(gpio_get(MODEM_STATUS_Port,MODEM_STATUS_Pin) == GPIO_STATE_HIGH){
      return true;
    }
    else {
      return false;
    }
  }
  return false;
}
